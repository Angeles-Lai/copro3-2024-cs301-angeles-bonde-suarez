﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wizard_Witch;

namespace Wizard_Witch
{
    interface sortCharactersIntoThereHouse
    {
        void sortCharac(); // ginamit natin toh para mag assign
    }

    struct Personality
    {
        public int Boldness { get; set; }
        public int Ambition { get; set; }
        public int Knowledge { get; set; }
        public int Loyalty { get; set; }
        public int Independence { get; set; }
        public int Resourcefulness { get; set; }
        public int Curiosity { get; set; }
        public int Dedication { get; set; }
        public int Adaptability { get; set; }
        public int Protectiveness { get; set; }
        public int Greatness { get; set; }
        public int Discovery { get; set; }
        public int Helping { get; set; }
        public int SelfTruth { get; set; }

        //constructor ng Personality class
        public Personality(int boldness, int ambition, int knowledge, int loyalty, int independence,
                           int resourcefulness, int curiosity, int dedication, int adaptability,
                           int protectiveness, int greatness, int discovery, int helping, int selfTruth)
        {
            this.Boldness = boldness;
            this.Ambition = ambition;
            this.Knowledge = knowledge;
            this.Loyalty = loyalty;
            this.Independence = independence;
            this.Resourcefulness = resourcefulness;
            this.Curiosity = curiosity;
            this.Dedication = dedication;
            this.Adaptability = adaptability;
            this.Protectiveness = protectiveness;
            this.Greatness = greatness;
            this.Discovery = discovery;
            this.Helping = helping;
            this.SelfTruth = selfTruth;
        }
        //ito naman is ginagamit para makuha ng method yung naka assign na personality
        public int GetBoldness() => this.Boldness;
        public int GetAmbition() => this.Ambition;
        public int GetKnowledge() => this.Knowledge;
        public int GetLoyalty() => this.Loyalty;
        public int GetIndependence() => this.Independence;
        public int GetResourcefulness() => this.Resourcefulness;
        public int GetCuriosity() => this.Curiosity;
        public int GetDedication() => this.Dedication;
        public int GetAdaptability() => this.Adaptability;
        public int GetProtectiveness() => this.Protectiveness;
        public int GetGreatness() => this.Greatness;
        public int GetDiscovery() => this.Discovery;
        public int GetHelping() => this.Helping;
        public int GetSelfTruth() => this.SelfTruth;
    }

    class House
    {
        public string AssignedHouse { get; set; }

        //constructor 
        public House(string assignedHouse)
        {
            this.AssignedHouse = assignedHouse;
        }

        //Yung method natoh mag d-display sa kung saang house ka na punta
        public void displayCharacterHouse()
        {

            Console.WriteLine("\n|     You are born to be " + this.AssignedHouse +"           |");
            Console.WriteLine("=============================================");
            Console.WriteLine("|       CHARACTER SUCCESFULLY CREATED!      |");
            Console.WriteLine("=============================================");
        }

        //inorride to string natin para ih return niya yung pangalan nung house
        public override string ToString()
        {
            return this.AssignedHouse;
        }
    }

    //SA CLASS NATO IS DITO MANG YAYARI YUNG WAY PARA MAG ASSIGN NG HOUSE LOGIC BA!

    class DesignatedHouse
    {
        public House AssignUsersHouse(int boldness, int ambition, int knowledge, int loyalty, int independence,
                                   int resourcefulness, int curiosity, int dedication, int adaptability,
                                   int protectiveness, int greatness, int discovery, int helping, int selfTruth)
        {
            // Initialize scores kumbaga mag tatally tas ku ng sino pinaka mataas na points yun ung house mo
            int gryffindorScore = 0;
            int ravenclawScore = 0;
            int hufflepuffScore = 0;
            int slytherinScore = 0;

            // Base ng scoring on the provided array traits
            // Gryffindor Traits
            gryffindorScore += boldness;
            gryffindorScore += ambition;
            gryffindorScore += adaptability;
            gryffindorScore += greatness;

            // Ravenclaw Traits
            ravenclawScore += knowledge;
            ravenclawScore += independence;
            ravenclawScore += curiosity;
            ravenclawScore += dedication;

            // Hufflepuff Traits
            hufflepuffScore += loyalty;
            hufflepuffScore += helping;
            hufflepuffScore += protectiveness;
            hufflepuffScore += adaptability;

            // Slytherin Traits 
            slytherinScore += ambition;
            slytherinScore += resourcefulness;
            slytherinScore += greatness;
            slytherinScore += selfTruth;

            // after makuha yung may pinaka mataas na points doon ma dedetermine kung anong house ka
            int maxScore = Math.Max(Math.Max(gryffindorScore, ravenclawScore),
                                    Math.Max(hufflepuffScore, slytherinScore));

            if (maxScore == gryffindorScore)
                return new House("Gryffindor");
            else if (maxScore == ravenclawScore)
                return new House("Ravenclaw");
            else if (maxScore == hufflepuffScore)
                return new House("Hufflepuff");
            else
                return new House("Slytherin");
        }
    }

    class CharacterPersonality : sortCharactersIntoThereHouse
    {
        //yung readonly bago ko siyang na tuklasan, according kay
        //google ginagamit daw yun para ih define yung field na isang
        //beses lang pwede ma assign yung value  
        private readonly Personality personality;  //dito mapupunta yung character personality
        private readonly DesignatedHouse houseFactory; //ito yung gagamitin para mag assign ng house base sa personality

        public CharacterPersonality()
        {
            this.houseFactory = new DesignatedHouse(); // Initialize the house factory (Composition)
            this.personality = GetPersonality();
            //ih a-assign natin yung houses dpende sa personality sa na kuhang sagot kay user
        }

        private Personality GetPersonality()
        {//array 
            string[] boldnessChoices = { "Boldly", "Strategically", "Creatively", "Dependably", "Calmly" };
            string[] ambitionChoices = { "Bravery", "Ambition", "Knowledge", "Loyalty", "Independence" };
            string[] knowledgeChoices = { "Lead", "Influence", "Advise", "Support", "Observe" };
            string[] loyaltyChoices = { "Courage", "Determination", "Intelligence", "Trustworthiness", "Open-mindedness" };
            string[] independenceChoices = { "Fearlessly", "Methodically", "Thoughtfully", "Persistently", "Flexibly" };
            string[] strengthChoices = { "Boldness", "Resourcefulness", "Curiosity", "Dedication", "Adaptability" };
            string[] motivationChoices = { "Protecting Others", "Achieving Greatness", "Discovering New Things", "Helping Those in Need", "Staying True to Yourself" };

            int boldness = AskUser("HOW DO YOU REACT TO A DIFFICULT SITUATION?", boldnessChoices);
            int ambition = AskUser("WHAT’S MOST IMPORTANT TO YOU IN LIFE?", ambitionChoices);
            int knowledge = AskUser("HOW DO YOU WORK WITH OTHERS?", knowledgeChoices);
            int loyalty = AskUser("WHAT DO YOU VALUE IN A FRIEND?", loyaltyChoices);
            int independence = AskUser("HOW DO YOU APPROACH YOUR GOALS?", independenceChoices);
            int resourcefulness = AskUser("WHAT IS YOUR BIGGEST STRENGTH?", strengthChoices);
            int motivation = AskUser("WHAT MOTIVATES YOU THE MOST?", motivationChoices);
            //question bkt ang daming 0, so yun yung parameter natin which is total of 7 then default na yung 0

            return new Personality(boldness, ambition, knowledge, loyalty, independence,
                                   resourcefulness, motivation, 0, 0, 0, 0, 0, 0, 0);
        }
        static void separator()
        {
            for (int i = 0; i < 45; i++)
            {
                Console.Write("=");
            }
        }
        // Base method natin
        private int AskUserCore(string question, string[] choices, int minRange, int maxRange)
        {
            int answer = 0;
            do
            {
                separator();
                Console.WriteLine($"\n{question}");
                for (int i = 0; i < choices.Length; i++)
                {
                    Console.WriteLine($"\n{i + 1}. {choices[i]}");
                }

                Console.Write($"Enter Your Answer ({minRange}-{maxRange}): ");
                try
                {
                    answer = int.Parse(Console.ReadLine());
                    if (answer < minRange || answer > maxRange)
                    {
                        Console.WriteLine($"\nInvalid input. Enter a number between {minRange} and {maxRange}.");
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("\nInvalid input. Enter a valid number.");
                }
            } while (answer < minRange || answer > maxRange);

            return answer;
        }

        // Overloaded methods
        private int AskUser(string question, string[] choices)
        {
            // Default range: 1 to 5
            return AskUserCore(question, choices, 1, 5);
        }

        private int AskUser(string question, string[] choices, int minRange, int maxRange)
        {
            return AskUserCore(question, choices, minRange, maxRange);
        }


        // Sort and assign the character to their house based on personality traits
        public void sortCharac()
        {
            House assignedHouse = this.houseFactory.AssignUsersHouse(
                this.personality.GetBoldness(),
                this.personality.GetAmbition(),
                this.personality.GetKnowledge(),
                this.personality.GetLoyalty(),
                this.personality.GetIndependence(),
                this.personality.GetResourcefulness(),
                this.personality.GetCuriosity(),
                this.personality.GetDedication(),
                this.personality.GetAdaptability(),
                this.personality.GetProtectiveness(),
                this.personality.GetGreatness(),
                this.personality.GetDiscovery(),
                this.personality.GetHelping(),
                this.personality.GetSelfTruth()
            );

            assignedHouse.displayCharacterHouse();
        }
    }

    
}