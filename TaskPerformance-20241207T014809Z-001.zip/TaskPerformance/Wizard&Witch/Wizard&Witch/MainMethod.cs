﻿using System;
using MySql.Data.MySqlClient;
using Wizard_Witch;

namespace DatabaseConnectionApp
{
    class MainMethod
    {
        public static void Main(string[] args)
        {
           string connectionString = "Server=localhost; Database=charactercreation; Uid=root; Pwd=;";
            character playerCharacter = new PlayersCharacter();

            try
            {
              

                GameOpening(playerCharacter);
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        static void GameOpening(character playerCharacter)
        {
            seperator();
            Console.WriteLine("\n            WELCOME TO\n        MAGIC CHRONICLES");
            seperator();

            string choice = GetOpeningChoice(new string[] { "NEW GAME", "LOAD GAME", "CAMPAIGN MODE", "CREDITS", "EXIT" });
            seperator();

            switch (choice)
            {
                case "NEW GAME":
                    Console.WriteLine("\nCREATE YOUR CHARACTER");
                    playerCharacter.physicalCharacteristic();
                    playerCharacter.mole();
                    playerCharacter.clothes();
                    playerCharacter.wands();
                    playerCharacter.stats();

                    CharacterPersonality personality = new CharacterPersonality();
                    playerCharacter.Features();
                    personality.sortCharac();
                    Console.WriteLine("\nDo you want to go back to Main Menu?\n[1] YES\n[2] NO");
                    Console.Write("Enter Your Choice: ");
                    int backChoice = Convert.ToInt32(Console.ReadLine());
                    if (backChoice == 1) GameOpening(playerCharacter);
                    else Console.WriteLine("\nThank You For Playing");
                    break;

                case "LOAD GAME":
                    Console.WriteLine("\nLoad Game");
                    break;

                case "CAMPAIGN MODE":
                    Console.WriteLine("\nCAMPAIGN MODE:");
                    Console.WriteLine("\nYou are living in a small village called ‘Wandborough’. " +
                         "Ever since you were born, people kept calling you a freak, witch, strange, " +
                         "and scary for being different from others. You were abandoned by your parents " +
                         "because they were ashamed and embarrassed to have you. However, who would’ve thought " +
                         "that the mockery would result in an identity crisis and confusion for you? " +
                         "But then one day, you met a beautiful and kind girl named ‘Elowen’. " +
                         "A special kid just like you, Elowen became close friends with you immediately after " +
                         "she saw you being bullied by normal kids. Because of that, Elowen introduced you to her academy, " +
                         "a place that will eventually help you find your way of living, a way of identifying your capabilities—" +
                         "where you will never be labeled as a ‘Freak, Witch, Strange, or Scary’.");

                    Console.WriteLine("\nThe day has come when you entered the academy. " +
                        "Everybody has their own specialties and powers, but somehow you still felt left out " +
                        "because you did not know how to manage your own powers. Fortunately, there’s a boy named ‘Albus’. " +
                        "The meaning of his name is ‘Bright or White,’ symbolizing leadership and wisdom. " +
                        "However, his name is completely opposite of his powers because, despite his bright name, " +
                        "he is a strong guy, and anyone who messes with him surely won’t wake up the next morning. " +
                        "But you are an exception. Albus found you in a way that he felt you needed to be taught and supported. " +
                        "Therefore, Albus taught you how to make use of your powers, gave you a wand, showed you how to fly, " +
                        "and taught you how to turn every fear into strength.");

                    Console.WriteLine("\nThe final stage has come where you need to choose your physical features and strengths " +
                        "based on your magical powers. To test if you really remembered everything that Albus taught you, " +
                        "he put you into the well-known challenge called ‘Mystic Quest Gauntlet.’ Here, you must navigate a series of " +
                        "increasingly difficult trials. Each trial is a combination of intelligence, bravery, resourcefulness, and magical ability. " +
                        "Whoever wins the challenge will not only earn glory but also a powerful magical artifact such as an amulet, " +
                        "as well as the title of ‘Master of the Mystic Quest.’");
                    Console.Write("\nPress any key to return to the main menu.");
                    Console.ReadKey();
                    Console.Write("\n");
                    GameOpening(playerCharacter);
                    break;

                case "CREDITS":
                    Console.WriteLine("\nCREATOR OF THE GAME:");
                    Console.WriteLine("\nAngeles, Laila O. \n- CS student soon mag s-shift sa ibang course\n" +
                        "\nBonde, Jenny \n- CS Student na magaling sa math at batak mag ML\n" +
                        "\nSuarez, Khatlyn \n- The best na singer ng CS301\n");
                    Console.WriteLine("\nPress any key to return to the main menu.");
                    Console.ReadKey();
                    GameOpening(playerCharacter);
                    break;

                case "EXIT":
                    Console.WriteLine("\nAre you sure you want to exit (yes/no)?");
                    string exit = Console.ReadLine()?.Trim().ToLower();
                    if (exit == "yes") Console.WriteLine("\nYou've successfully exited the game!");
                    else GameOpening(playerCharacter);
                    break;

                default:
                    Console.WriteLine("\nInvalid choice. Please try again.");
                    GameOpening(playerCharacter);
                    break;
            }
        }

        static void seperator()
        {
            for (int i = 0; i < 45; i++)
            {
                Console.Write("=");
            }
            Console.WriteLine();
        }

        static string GetOpeningChoice(string[] options)
        {
            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine($"[{i + 1}] {options[i]}");
            }

            Console.Write("\nEnter The Number Of Your Choice: ");
            int chosen;

            while (!int.TryParse(Console.ReadLine(), out chosen) || chosen < 1 || chosen > options.Length)
            {
                Console.WriteLine("\nInvalid Input. Please enter a valid option.");
                Console.Write("Enter The Number Of Your Choice: ");
            }

            return options[chosen - 1];
        }
    }
}
