﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using ZstdSharp.Unsafe;

namespace DatabaseConnectionApp
{

    abstract class character//abstract class 
    {//Method Overriding & abstact method
        public abstract void physicalCharacteristic();
        public abstract bool mole();
        public abstract void clothes();
        public abstract void wands();
        public abstract void stats();

        public abstract void Features();
    }
    class PlayersCharacter : character
    //inenherit ni playerChracter si abstract character
    {
        //encapsulation
        //string for character physical feature
        public string EyeColor { get; private set; }
        public string HairColor { get; private set; }
        public string FaceShape { get; private set; }
        public string BodyShape { get; private set; }
        public string HairLength { get; private set; }
        public string lipColor { get; private set; }
        public string skinTone { get; private set; }
        public string height { get; private set; }
        public string Gender { get; private set; }

        //  bool
        public bool HasMole { get; private set; }
        //string clothes and wand

        public string outfit { get; private set; }
        public string wand { get; private set; }


        //integer

        private const int MaxPoints = 20;
        private int remainingPoints = MaxPoints;
       
        public int Intelligence { get; private set; }
        public int Luck { get; private set; }
        public int Strength { get; private set; }
        public int Endurance { get; private set; }
        public int Speed { get; private set; }
     
  
 


        static void seperator()
        {
            for (int i = 0; i < 45; i++)
            {
                Console.Write("=");
            }
        }

        //Ito yung method na tinatawag para mag labas ng invalid message
        static void invalidmessage()
        {
            Console.WriteLine("\nInvalid Input, Please try again");
        }

        public override void physicalCharacteristic()
        {
            EyeColor = physicalCharacteristic("Choose Eye Color:", new string[] { "BLACK", "BROWN", "BLUE", "GREEN", "WHITE" });
            HairColor = physicalCharacteristic("Choose Hair Color:", new string[] { "BLACK", "BROWN", "BLUE", "GREEN", "WHITE" });
            FaceShape = physicalCharacteristic("Choose Face Shape:", new string[] { "OVAL", "ROUND", "HEART", "DIAMOND", "RECTANGULAR" });
            BodyShape = physicalCharacteristic("Choose Body Shape:", new string[] { "RECTANGULAR", "HOUR GLASS", "APPLE", "PEAR", "TRIANGLE" });
            HairLength = physicalCharacteristic("Choose Hair Length:", new string[] { "BALD", "MEDIUM", "SHORT", "LONG", "WAIST LENGTH" });
            lipColor = physicalCharacteristic("Choose Lip Color:", new string[] { "NATURAL", "GREEN", "PINK", "RED", "VIOLET" });
            skinTone = physicalCharacteristic("Choose Skin Tone:", new string[] { "PORCELAIN", "TAN", "OLIVE", "BEIGE", "CHOCOLATE" });
            height = physicalCharacteristic("Choose Height:", new string[] { "VERY SHORT     (120-149cm)", "SHORT          (150-164cm)", "AVERAGE        (165-179 cm)", "TALL           (180-199 cm)", "VERY TALL      (200-250 cm)" });
            Gender = physicalCharacteristic("Choose Gender:", new string[] { "FEMALE", "MALE", "HETERO", "HOMO", "NON-BINARY" });
        }

        //Method para sa string
        private string physicalCharacteristic(string message, string[] options)
        {
            Console.WriteLine("\n" + message);

            for (int i = 0; i < options.Length; i++)
            {//for loop para ma display each options at the same time ilalagay pang ilang choice para hind hussle kung ako pa mag t-type hehe katamad
                Console.WriteLine($"[{i + 1}] {options[i]}");
            }
            Console.Write("Enter The Number Of Your Choice: ");
            int chosen;
            //sa part na toh is yung while loop is yung mag vavalidate if tama ba yung inenter na value ni user mag loloop siya if false lagi yung input ni user
            while (!int.TryParse(Console.ReadLine(), out chosen) || chosen < 1 || chosen > options.Length)
            {
                invalidmessage();
                Console.Write("Enter The Number Of Your Choice: ");
            }
            seperator();
            return options[chosen - 1];
        }

        public override bool mole()
        {
    
            while (true)
            {
                Console.WriteLine("\nAdd a mole underneath the right eye?\n[1] YES\n[2] NO");
                Console.Write("Enter (1 or 2): ");
                string choice = Console.ReadLine();


                if (choice.Equals("1"))
                {
                    HasMole = true;
                    return true;
                }
                else if (choice.Equals("2"))
                {
                    HasMole = false;
                    return false;
                }
                else
                {
                    invalidmessage();
                    
                }

             
            }
            
        }

        //wand and clothes ni wizard
        public override void clothes()
        {
            
            (string name, string description)[] options =
            {
            ("Mystic Robes of the Arcane", "Flowing robes adorned with glowing runes, perfect for spellcasters seeking ultimate power."),
            ("Shadow Cloak of Secrets", "A dark, hooded cloak that blends into the night, ideal for stealthy wizards and witches."),
            ("Battle-Enchanted Armor", "Magical armor that combines protection with charm, suited for warriors of the arcane arts."),
            ("Ethereal Silk Ensemble", "Lightweight, shimmering garments that radiate elegance, perfect for enchanting others."),
            ("Elemental Tunic and Cape", "A vibrant outfit channeling the power of fire, water, earth, and air, for nature-bound spellcasters.")
            };

            // tatawagin si getOutfit method para mag display options and kunin yung  user's choice
            string chosenOutfit = clothes("Choose Your Wizard/Witch Outfit", options);

        }

        public override void wands()
        {
            //for wand
            (string name, string description)[] options =
           {
            ("Elderwood Wand", "Crafted from ancient elder trees, this wand is known for its unmatched power and wisdom."),
            ("Phoenix Feather Core Wand", "Infused with a phoenix feather, it grants incredible versatility and resilience."),
            ("Dragon Heartstring Wand", "A fiery wand with a fierce temper, ideal for bold and daring spellcasters."),
            ("Willow Wand of Healing", "Made from willow, this wand excels in protective and restorative magic."),
            ("Obsidian Crystal Wand", "Forged from volcanic glass, it channels dark and mysterious energy for intricate spells\n")
            };
          
            // tatawagin si getOutfit method para mag display options and kunin yung  user's choice
            string wandoption = wands("Choose Your Magical Wand:", options);
            seperator();
        }

        // ito yung method para lumabas yung question, option saka description ng wand and clothes method
        private string clothes(string question, (string name, string description)[] options)
        {
            seperator();
            Console.WriteLine($"\n{question}:");

            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine($"\n[{i + 1}] {options[i].name}");
                Console.WriteLine($"\n-{options[i].description}\n");
            }

            
            Console.Write("Enter The Number Of Your Choice: ");
            int chosen;

           
            while (!int.TryParse(Console.ReadLine(), out chosen) || chosen < 1 || chosen > options.Length)
            {
                Console.WriteLine("Invalid choice. Please enter a valid number between 1 and 5.");
                Console.Write("Enter The Number Of Your Choice: ");
            }

            // Return the chosen outfit name
            outfit = options[chosen -1].name;
         
            return outfit;

        }
        private string wands(string question, (string name, string description)[] options)
        {
            seperator();
            Console.WriteLine($"\n{question}:");

            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine($"\n[{i + 1}] {options[i].name}");
                Console.WriteLine($"\n-{options[i].description}\n");
            }


            Console.Write("Enter The Number Of Your Choice: ");
            int chosen;


            while (!int.TryParse(Console.ReadLine(), out chosen) || chosen < 1 || chosen > options.Length)
            {
                Console.WriteLine("Invalid choice. Please enter a valid number between 1 and 5.");
                Console.Write("Enter The Number Of Your Choice: ");
            }

            // Return the chosen wand name
            wand = options[chosen - 1].name;
            return wand;

        }

        //method which ina allow si user na pumili ng category sa stats and mag c-continue siya mag tatanong hangang sa maubos yung 20 pnts

        public override void stats()
        {
            int totalAllocatedPoints = 0;
            Console.WriteLine("\nChoose the stat you want to allocate points to:\n" +
            "Rules:\nYou must distribute all 20 points across the stats you pick.\n" +
            "The system will keep asking until the total allocation equals 20 points.\n"
            + "Note: Each stat must have a value between 0 and 7, so allocate wisely.");
            seperator();
            Console.WriteLine("\n[1] Intelligence \n- Your ability to solve problems and master spells.\n");
            Console.WriteLine("[2] Luck \n- The probability of favorable outcomes in unpredictable situations.\n");
            Console.WriteLine("[3] Strength \n- The measure of your physical power and combat prowess.\n");
            Console.WriteLine("[4] Endurance \n- Your capacity to withstand damage and sustain physical effort.\n");
            Console.Write("[5] Speed \n- Your agility and swiftness in both movement and reaction.\n");


            while (remainingPoints > 0)
            {
                Console.WriteLine($"\nRemaining Points: {remainingPoints}");
                Console.Write("Choose a stat you want to put points to (1-5): ");
    
                if (int.TryParse(Console.ReadLine(), out int chosenCategory) && chosenCategory >= 1 && chosenCategory <= 5)
                {
                    Console.Write("Enter points: ");
                    if (int.TryParse(Console.ReadLine(), out int points) && points > 0 && points <= remainingPoints)
                    {
                      //after mag input ni user ng points is titingnan muna if yung points na binigay niya is mas mataas sa limit natin na 7
                        if (points > 7)
                        {//if mataas yung points na binigay niya kesa sa limit natin is mag lalabas siya ng warning
                            seperator();
                            Console.WriteLine("\nWarning: You have allocated more than 7 points to a stat. \nPlease ensure each stat is within the limit of 0 to 7.");
                            seperator();
                        }
                        else
                        {


                            // if Valid yung input mag update yung stat and mag d-deduct yung remaining points and points na ininput ni user
                            stats(chosenCategory, points);
                            remainingPoints -= points;
                            totalAllocatedPoints += points;
                            update();

                            // update() is yung method na tinawag natin para ih display yung mga update ng points
                        }
                        //yung 20 na pnts natin is ma d-deduct siya everytime na nag bibigay tayo ng pnts and once na naging 0 na si remaining pnts hindi na siya mag tatanong
                    }

                    else
                    {
                        seperator();
                        Console.WriteLine("\nInvalid Points!");
                        seperator();
                    }
                }
                else
                {
                    seperator();
                    Console.WriteLine("\nWarning: Please select a number between 1-5");
                    seperator();
                }
            }


        }

        private void stats(int category, int points)
        {
            switch (category)
            {
                case 1:
                    if (Intelligence >= 7)
                    {
                        Console.WriteLine("\nWarning: Intelligence is already at the maximum limit of 7 points.");
                        remainingPoints += points;
                       
                    }
                    else
                    {
                        Intelligence += points;
                    }
                    break;

                case 2:
                    if (Luck >= 7)
                    {
                        Console.WriteLine("\nWarning: Luck is already at the maximum limit of 7 points.");
                        remainingPoints += points;
                    }
                    else
                    {
                        Luck += points;
                    }
                    break;

                case 3:
                    if (Strength >= 7)
                    {
                        Console.WriteLine("\nWarning: Strength is already at the maximum limit of 7 points.");
                        remainingPoints += points;
                    }
                    else
                    {
                        Strength += points;
                    }
                    break;

                case 4:
                    if (Endurance >= 7)
                    {
                        Console.WriteLine("\nWarning: Endurance is already at the maximum limit of 7 points.");
                        remainingPoints += points;
                    }
                    else
                    {
                        Endurance += points;
                    }
                    break;

                case 5:
                    if (Speed >= 7)
                    {
                        Console.WriteLine("\nWarning: Speed is already at the maximum limit of 7 points.");
                        remainingPoints += points;
                    }
                    else
                    {
                        Speed += points;
                    }
                    break;

                default:
                    Console.WriteLine("\nInvalid category selected.");
                    break;
            }
            seperator();
        }


        //METHOD NA TINATAWAG NATIN PARA IPA KITA YUNG STATS NI USER EVERY TIME NA NAG BIBIGAY SIYA NG POINTS
        private void update()
        {
          
            Console.WriteLine("\nUPDATED STATS:\n");
            Console.WriteLine($"Intelligence: {Intelligence}");
            Console.WriteLine($"Luck: {Luck}");
            Console.WriteLine($"Strength: {Strength}");
            Console.WriteLine($"Endurance: {Endurance}");
            Console.WriteLine($"Speed: {Speed}");
            seperator();
        }


        //after makuha lahat ng needed info ito na yung method para ih display lahat
        public override void Features()
        {
            seperator();
            Console.WriteLine("\nPHYSICAL APPEARANCE\n");
            Console.WriteLine($"Eye Color: {EyeColor}");
            Console.WriteLine($"Hair Color: {HairColor}");
            Console.WriteLine($"Face Shape: {FaceShape}");
            Console.WriteLine($"Body Shape: {BodyShape}");
            Console.WriteLine($"Hair Length: {HairLength}");
            Console.WriteLine($"Lip Color: {lipColor}");
            Console.WriteLine($"Skin Tone: {skinTone}");
            Console.WriteLine($"Height: {height}");
            Console.WriteLine($"Eye Color: {Gender}");
            //mole

            bool moleResult = HasMole;
            Console.Write($"Mole underneath the right eye: {moleResult}\n");
            //CLOTHES AND WAND
            seperator();
            Console.WriteLine("\nCLOTHES AND WAND:\n");
            Console.WriteLine($"Outfit: {outfit}");
            Console.WriteLine($"Wand: {wand}");
            Console.WriteLine("\nCharacter Created Succesfully!\n");
           

            //stats
            seperator();
            Console.WriteLine("\nSTATS:\n");
            Console.WriteLine($"Intelligence: {Intelligence}");
            Console.WriteLine($"Luck: {Luck}");
            Console.WriteLine($"Strength: {Strength}");
            Console.WriteLine($"Endurance: {Endurance}");
            Console.WriteLine($"Speed: {Speed}");
            seperator();
        }
    }
}
